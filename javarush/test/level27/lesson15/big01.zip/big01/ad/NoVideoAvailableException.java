package com.javarush.test.level27.lesson15.big01.ad;

/**
 * Created by Alexey on 16.02.2016.
 */
public class NoVideoAvailableException extends Exception
{
}
