package com.javarush.test.level27.lesson15.big01;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alexey on 15.02.2016.
 */
public class ConsoleHelperTest
{

    @Test
    public void testGetAllDishesForOrder() throws Exception
    {

        System.out.println(ConsoleHelper.getAllDishesForOrder());
    }
}