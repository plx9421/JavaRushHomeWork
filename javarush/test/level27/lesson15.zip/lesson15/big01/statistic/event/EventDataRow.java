package com.javarush.test.level27.lesson15.big01.statistic.event;

/**
 * Created by Alexey on 13.03.2016.
 */
public interface EventDataRow {

   EventType getType();

}
